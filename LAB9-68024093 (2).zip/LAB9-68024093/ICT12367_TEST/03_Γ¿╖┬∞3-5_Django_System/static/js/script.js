const textarea = document.getElementById("feedbackText");
const count = document.getElementById("charCount");

if (textarea) {
    textarea.addEventListener("input", function() {
        count.textContent = textarea.value.length;
    });
}