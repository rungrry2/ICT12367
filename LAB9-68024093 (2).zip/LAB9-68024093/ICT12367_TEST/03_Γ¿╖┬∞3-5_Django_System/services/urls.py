from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),          # <-- หน้า Home
    path('products/', views.products, name='products'),
    path('feedback/', views.feedback, name='feedback'),
]