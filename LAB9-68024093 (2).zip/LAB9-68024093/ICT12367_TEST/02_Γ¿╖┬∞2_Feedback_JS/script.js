const textarea = document.getElementById("feedbackText");
const charCount = document.getElementById("charCount");

textarea.addEventListener("keyup", function(){

let length = textarea.value.length;

charCount.textContent = length;

});